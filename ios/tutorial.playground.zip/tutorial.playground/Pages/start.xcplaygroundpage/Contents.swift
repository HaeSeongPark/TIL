//: [Previous](@previous)

//: Swift 문법

//: 복습 : 변수(var), 상수(let), if(조건문), func(함수)

//: 변수는 속성이고 대명사이다.  함수는 행위, 기능

//: 할 것 : func 추가(정의, 호출), 클래스, 프로그래밍, 프로그래밍언어, 주석의 의미, Casting(as), Optional( ?, ! ), Array(배열), if else == boolean
var test = "test"

let thisCompayName = "헬로네이처"
var worker = ["임진우", "박해성", "홍재진","전진수","진수연","윤재연"]
worker.append("허광남")
var workers = worker.joined(separator: " ")
print("\(workers) work at a \(thisCompayName)")
//if test = "test"{
//
//}
//
//var a = 1
//a = "abc"
//: [Next](@next)
