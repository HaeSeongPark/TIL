//: [Previous](@previous)

//: Playground - noun: a place where people can play


//: 변수는 대명사이다.
//:
import UIKit

var str = "Hello, playground"
var a = [[String]]()
var b = [String]()
 b  = ["a","a","a","a"]

a = [ b,b,b ]

//: [Next](@next)
